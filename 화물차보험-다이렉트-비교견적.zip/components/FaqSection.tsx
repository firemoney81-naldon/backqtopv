
import React, { useState } from 'react';

interface FaqItemProps {
    question: string;
    answer: string;
    isOpen: boolean;
    onClick: () => void;
}

const FaqItem: React.FC<FaqItemProps> = ({ question, answer, isOpen, onClick }) => {
    return (
        <div className="border-b border-gray-200 py-5">
            <dt>
                <button onClick={onClick} className="w-full text-left flex justify-between items-start text-brand-text">
                    <span className="text-lg font-medium">{question}</span>
                    <span className="ml-6 h-7 flex items-center">
                        <svg className={`h-6 w-6 transform transition-transform ${isOpen ? '-rotate-180' : 'rotate-0'}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </span>
                </button>
            </dt>
            {isOpen && (
                <dd className="mt-2 pr-12">
                    <p className="text-base text-brand-text-light">{answer}</p>
                </dd>
            )}
        </div>
    );
};


const FaqSection: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(null);

    const faqs = [
        {
            question: "영업용 화물차보험료는 왜 개인 승용차보다 비싼가요?",
            answer: "영업용 화물차는 주행거리가 길고, 사고 발생 시 피해 규모가 크며, 적재물에 대한 위험까지 포함하기 때문에 개인 승용차 보험보다 보험료가 높게 책정됩니다. 또한, 운행 목적 자체가 상업적이라 위험도가 더 높게 평가됩니다."
        },
        {
            question: "화물차공제조합과 일반 보험사의 가장 큰 차이점은 무엇인가요?",
            answer: "화물차공제조합은 화물운송사업자들의 협동조직으로, 조합원을 대상으로 운영됩니다. 반면 일반 보험사는 불특정 다수를 대상으로 하는 영리 기업입니다. 일반적으로 공제조합이 특정 차종에 대해 저렴할 수 있으나, 보상 처리 서비스나 특약 다양성 면에서는 일반 보험사가 더 나은 경험을 제공할 수 있습니다."
        },
        {
            question: "1톤 트럭 개인용달 보험료를 절약하는 가장 효과적인 방법은 무엇인가요?",
            answer: "가장 효과적인 방법은 다이렉트 보험 비교 사이트를 통해 여러 보험사의 견적을 한 번에 받아보는 것입니다. 이외에도 운전 경력을 인정받고, 무사고 운전을 유지하며, DTG(디지털 운행기록계) 할인, 안전장치 할인 등 본인에게 적용 가능한 특약을 최대한 활용하는 것이 중요합니다."
        },
        {
            question: "화물차보험 가입 시 적재물 배상책임보험을 꼭 들어야 하나요?",
            answer: "적재물 배상책임보험은 의무는 아니지만, 운송 중인 화물에 손해가 발생했을 때 이를 보상해주는 중요한 보험입니다. 고가의 화물을 운송하거나 거래처에서 요구하는 경우가 많으므로, 사업의 안정성을 위해 가입하는 것을 강력히 추천합니다."
        }
    ];

    const handleToggle = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <section className="bg-brand-bg-light py-20">
            <div className="container mx-auto px-6 max-w-4xl">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-brand-primary">자주 묻는 질문 (FAQ)</h2>
                    <p className="mt-4 text-lg text-brand-text-light">화물차보험에 대해 가장 궁금해하시는 점들을 모았습니다.</p>
                </div>
                <div className="bg-white p-8 rounded-xl shadow-lg">
                    <dl className="space-y-4">
                        {faqs.map((faq, index) => (
                            <FaqItem
                                key={index}
                                question={faq.question}
                                answer={faq.answer}
                                isOpen={openIndex === index}
                                onClick={() => handleToggle(index)}
                            />
                        ))}
                    </dl>
                </div>
            </div>
        </section>
    );
};

export default FaqSection;
