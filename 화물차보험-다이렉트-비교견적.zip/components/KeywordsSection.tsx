
import React from 'react';

const KeywordsSection: React.FC = () => {
    const keywords = [
        '#영업용화물차보험',
        '#1톤트럭보험료',
        '#개인용달보험비교',
        '#화물차보험가입',
        '#다이렉트화물차보험',
        '#화물차공제조합',
        '#법인화물차보험',
        '#트럭보험최저가',
    ];

    return (
        <section className="py-16 bg-white">
            <div className="container mx-auto px-6">
                <h3 className="text-center text-2xl font-bold text-brand-primary mb-8">함께 많이 찾는 키워드</h3>
                <ul className="flex flex-wrap justify-center gap-3 md:gap-4">
                    {keywords.map((keyword, index) => (
                        <li key={index} className="bg-blue-100 text-brand-secondary font-semibold px-4 py-2 rounded-full text-sm md:text-base cursor-pointer hover:bg-brand-secondary hover:text-white transition-colors">
                            {keyword}
                        </li>
                    ))}
                </ul>
            </div>
        </section>
    );
};

export default KeywordsSection;
