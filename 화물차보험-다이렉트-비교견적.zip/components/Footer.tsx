
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="bg-brand-bg-dark text-white">
            <div className="container mx-auto px-6 py-12 text-center">
                <p className="font-bold text-lg mb-4">화물차보험 다이렉트</p>
                <div className="flex justify-center space-x-6 mb-6 text-gray-400">
                    <a href="#" className="hover:text-white transition-colors">개인정보처리방침</a>
                    <a href="#" className="hover:text-white transition-colors">이용약관</a>
                    <a href="#" className="hover:text-white transition-colors">문의하기</a>
                </div>
                <p className="text-sm text-gray-500 max-w-3xl mx-auto mb-6">
                    본 사이트는 보험료 비교 정보를 제공하는 플랫폼이며, 실제 보험 계약은 각 보험사의 공식 홈페이지 또는 앱을 통해 직접 체결됩니다. 당사는 보험 계약의 직접적인 당사자가 아니며, 제공된 정보에 대한 법적 책임을 지지 않습니다.
                </p>
                <p className="text-sm text-gray-400">&copy; {new Date().getFullYear()} 화물차보험 다이렉트. All Rights Reserved.</p>
            </div>
        </footer>
    );
};

export default Footer;
