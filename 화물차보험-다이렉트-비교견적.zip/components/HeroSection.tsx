
import React from 'react';
import QuoteForm from './QuoteForm';

const HeroSection: React.FC = () => {
    return (
        <section className="bg-gradient-to-br from-brand-primary to-brand-bg-dark text-white pt-20 pb-24">
            <div className="container mx-auto px-6 text-center">
                <h1 className="text-4xl md:text-5xl font-black leading-tight mb-4">
                    화물차보험, 가장 현명하게 가입하는 방법
                </h1>
                <p className="text-lg md:text-xl mb-12 max-w-3xl mx-auto text-gray-300">
                    2026년 최신 정보를 반영한 다이렉트 보험료를 실시간으로 비교하고,
                    <br />
                    내 조건에 딱 맞는 최저가 영업용 화물차보험을 찾아보세요.
                </p>
                <div className="max-w-4xl mx-auto">
                    <QuoteForm />
                </div>
            </div>
        </section>
    );
};

export default HeroSection;
