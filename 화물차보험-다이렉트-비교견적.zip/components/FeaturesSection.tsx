
import React from 'react';

const FeatureCard: React.FC<{ title: string; description: string; icon: React.ReactNode }> = ({ title, description, icon }) => (
    <div className="bg-white p-8 rounded-xl shadow-lg transform hover:-translate-y-2 transition-transform duration-300">
        <div className="flex items-center justify-center h-16 w-16 rounded-full bg-blue-100 text-brand-secondary mb-5">
            {icon}
        </div>
        <h3 className="text-xl font-bold text-brand-primary mb-2">{title}</h3>
        <p className="text-brand-text-light">{description}</p>
    </div>
);

const FeaturesSection: React.FC = () => {
    const features = [
        {
            title: '1분 초고속 견적',
            description: '차량과 운전자 정보만으로 국내 주요 보험사의 화물차보험료를 지체 없이 비교합니다.',
            icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>,
        },
        {
            title: '최저가 보장 설계',
            description: '동일 보장 기준, 고객님의 조건에 맞는 가장 저렴한 다이렉트 보험을 찾아드립니다.',
            icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
        },
        {
            title: '원스톱 간편 가입',
            description: '복잡한 절차 없이, 최적의 상품 선택 후 해당 보험사에서 바로 가입을 완료할 수 있습니다.',
            icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>,
        },
    ];

    return (
        <section className="py-20 bg-brand-bg-light">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                     <h2 className="text-3xl md:text-4xl font-bold text-brand-primary">
                        왜 <span className="text-brand-secondary">화물차보험 다이렉트</span>인가?
                    </h2>
                    <p className="mt-4 text-lg text-brand-text-light max-w-2xl mx-auto">
                        저희는 단순한 가격 비교를 넘어, 사업자님의 성공적인 운행을 위한 최적의 파트너가 되어 드립니다.
                    </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {features.map((feature, index) => (
                        <FeatureCard key={index} {...feature} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FeaturesSection;
