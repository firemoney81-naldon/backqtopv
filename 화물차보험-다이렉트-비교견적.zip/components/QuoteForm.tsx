
import React, { useState, FormEvent } from 'react';

type Step = 1 | 2 | 3 | 4;

const QuoteForm: React.FC = () => {
    const [step, setStep] = useState<Step>(1);
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        vehicleType: '1톤 이하 카고',
        vehicleYear: '2023',
        businessType: '개인용달',
        driverAge: '30',
        drivingExperience: '3년 이상',
        accidentHistory: '없음',
        coverageAmount: '10억',
    });

    const handleNext = () => {
        if (step < 4) {
            setStep((prevStep) => (prevStep + 1) as Step);
        }
    };
    
    const handleBack = () => {
        if (step > 1) {
             setStep((prevStep) => (prevStep - 1) as Step);
        }
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        alert('최저가 보험료 조회가 완료되었습니다. 전문 상담원이 곧 연락드리겠습니다.');
        // In a real app, you would send formData to a server here.
    };

    const renderStep = () => {
        switch (step) {
            case 1:
                return (
                    <div>
                        <h3 className="text-xl font-bold text-brand-primary mb-4">1단계: 기본 정보 입력</h3>
                        <div>
                            <label htmlFor="name" className="text-left block text-brand-text font-semibold mb-2">이름</label>
                            <input type="text" id="name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} placeholder="홍길동" required className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary"/>
                        </div>
                        <div className="mt-4">
                            <label htmlFor="phone" className="text-left block text-brand-text font-semibold mb-2">연락처</label>
                            <input type="tel" id="phone" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} placeholder="010-1234-5678" required className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary"/>
                        </div>
                    </div>
                );
            case 2:
                return (
                    <div>
                        <h3 className="text-xl font-bold text-brand-primary mb-4">2단계: 화물차 정보</h3>
                         <div>
                            <label htmlFor="vehicleType" className="text-left block text-brand-text font-semibold mb-2">차종 및 톤수</label>
                            <select id="vehicleType" value={formData.vehicleType} onChange={(e) => setFormData({...formData, vehicleType: e.target.value})} className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary">
                                <option>1톤 이하 카고</option>
                                <option>1.2톤 ~ 2.5톤 카고</option>
                                <option>2.5톤 ~ 5톤 카고</option>
                                <option>5톤 이상 카고</option>
                                <option>덤프트럭</option>
                                <option>트랙터(추레라)</option>
                                <option>냉동/냉장탑차</option>
                                <option>기타 특장차</option>
                            </select>
                        </div>
                        <div className="mt-4">
                            <label htmlFor="vehicleYear" className="text-left block text-brand-text font-semibold mb-2">차량 연식</label>
                            <input type="text" id="vehicleYear" value={formData.vehicleYear} onChange={(e) => setFormData({...formData, vehicleYear: e.target.value})} placeholder="예: 2024" className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary"/>
                        </div>
                        <div className="mt-4">
                            <label htmlFor="businessType" className="text-left block text-brand-text font-semibold mb-2">운송 사업 종류</label>
                             <select id="businessType" value={formData.businessType} onChange={(e) => setFormData({...formData, businessType: e.target.value})} className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary">
                                <option>개인용달</option>
                                <option>개별화물</option>
                                <option>법인(일반)화물</option>
                            </select>
                        </div>
                    </div>
                );
            case 3:
                 return (
                    <div>
                        <h3 className="text-xl font-bold text-brand-primary mb-4">3단계: 운전자 정보</h3>
                         <div>
                            <label htmlFor="driverAge" className="text-left block text-brand-text font-semibold mb-2">운전자 연령</label>
                             <select id="driverAge" value={formData.driverAge} onChange={(e) => setFormData({...formData, driverAge: e.target.value})} className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary">
                                <option>26세 이상</option>
                                <option>30세 이상</option>
                                <option>40세 이상</option>
                                <option>50세 이상</option>
                            </select>
                        </div>
                        <div className="mt-4">
                            <label htmlFor="drivingExperience" className="text-left block text-brand-text font-semibold mb-2">운전 경력</label>
                             <select id="drivingExperience" value={formData.drivingExperience} onChange={(e) => setFormData({...formData, drivingExperience: e.target.value})} className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary">
                                <option>1년 미만</option>
                                <option>1년 ~ 3년</option>
                                <option>3년 이상</option>
                            </select>
                        </div>
                        <div className="mt-4">
                            <label htmlFor="accidentHistory" className="text-left block text-brand-text font-semibold mb-2">3년 내 사고 이력</label>
                             <select id="accidentHistory" value={formData.accidentHistory} onChange={(e) => setFormData({...formData, accidentHistory: e.target.value})} className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary">
                                <option>없음</option>
                                <option>1회</option>
                                <option>2회 이상</option>
                            </select>
                        </div>
                    </div>
                );
            case 4:
                return (
                     <div>
                        <h3 className="text-xl font-bold text-brand-primary mb-4">4단계: 희망 보장 내역</h3>
                         <div>
                            <label htmlFor="coverageAmount" className="text-left block text-brand-text font-semibold mb-2">대물배상 가입금액</label>
                             <select id="coverageAmount" value={formData.coverageAmount} onChange={(e) => setFormData({...formData, coverageAmount: e.target.value})} className="w-full p-3 border border-gray-300 rounded-md text-brand-text focus:ring-2 focus:ring-brand-secondary">
                                <option>2억</option>
                                <option>3억</option>
                                <option>5억</option>
                                <option>10억</option>
                            </select>
                        </div>
                         <div className="mt-6 text-left text-sm text-brand-text-light">
                            <p className="font-semibold">기본 보장 항목:</p>
                            <p>대인배상Ⅰ(의무), 대인배상Ⅱ(무한), 자기신체사고(1억), 무보험차상해(2억)</p>
                            <p className="mt-2">* 상세 담보 및 추가 특약은 상담 시 조절 가능합니다.</p>
                         </div>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="bg-white p-6 md:p-10 rounded-2xl shadow-2xl text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-brand-primary mb-2">
                실시간 화물차보험료 비교견적
            </h2>
            <p className="text-brand-text-light mb-6">
                간단 정보 입력으로 2026년 최저가 보험료를 바로 확인하세요.
            </p>
            <form onSubmit={handleSubmit}>
                <div className="min-h-[280px]">
                    {renderStep()}
                </div>
                <div className="flex justify-between items-center mt-6">
                     {step > 1 && <button type="button" onClick={handleBack} className="bg-gray-200 text-brand-text font-bold py-3 px-6 rounded-full transition-transform transform hover:scale-105">이전</button>}
                     <div className="flex-grow text-center text-brand-text-light font-medium">{step} / 4 단계</div>
                     {step < 4 && <button type="button" onClick={handleNext} className="bg-brand-secondary text-white font-bold py-3 px-6 rounded-full transition-transform transform hover:scale-105">다음</button>}
                     {step === 4 && <button type="submit" className="bg-brand-cta text-white font-bold py-3 px-6 rounded-full transition-transform transform hover:scale-105 shadow-lg">최저가 견적 받기</button>}
                </div>
            </form>
        </div>
    );
};

export default QuoteForm;
