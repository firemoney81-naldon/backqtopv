
import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import FeaturesSection from './components/FeaturesSection';
import ReportSection from './components/ReportSection';
import FaqSection from './components/FaqSection';
import Footer from './components/Footer';
import KeywordsSection from './components/KeywordsSection';

const App: React.FC = () => {
    return (
        <div className="bg-brand-bg-light text-brand-text font-sans">
            <Header />
            <main>
                <HeroSection />
                <FeaturesSection />
                <KeywordsSection />
                <ReportSection />
                <FaqSection />
            </main>
            <Footer />
        </div>
    );
};

export default App;
